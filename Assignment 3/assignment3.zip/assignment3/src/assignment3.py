# -*- coding: utf-8 -*-
"""
   Assignment 3: Sentiment Classification on a Feed-Forward Neural Network using Pretrained Embeddings
   Original code by Hande Celikkanat & Miikka Silfverberg.
"""

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import gensim
import os

# Add the path to these data manipulation files if necessary:
# import sys
# sys.path.append('</PATH/TO/DATA/MANIP/FILES>')
from data_semeval import *
from paths import data_dir, model_dir

# name of the embeddings file to use
# Alternatively, you can also use the full set,
#
# GoogleNews-vectors-negative300.bin (from https://code.google.com/archive/p/word2vec/)
embeddings_file = 'GoogleNews-pruned2tweets.bin'

# --- hyperparameters ---

# Feel free to experiment with different hyperparameters to see how they compare!
# You can turn in your assignment with the best settings you find.

n_classes = len(LABEL_INDICES)
n_epochs = 30
learning_rate = 0.001
report_every = 1
verbose = False


# --- auxilary functions ---

# To convert string label to pytorch format:
def label_to_idx(label):
    return torch.LongTensor([LABEL_INDICES[label]])




# --- model ---

class FFNN(nn.Module):
    # Feel free to add whichever arguments you like here.
    # Note that pretrained_embeds is a numpy matrix of shape (num_embeddings, embedding_dim)
    def __init__(self, pretrained_embeds, n_classes, extra_arg_1=None, extra_arg_2=None):
        super(FFNN, self).__init__()

        # WRITE CODE HERE
        pass


    def forward(self, x):
        # WRITE CODE HERE
        pass


# --- "main" ---

if __name__ == '__main__':

    # --- data loading ---
    data = read_semeval_datasets(data_dir)
    gensim_embeds = gensim.models.KeyedVectors.load_word2vec_format(os.path.join(model_dir, embeddings_file),
                                                                    binary=True)
    pretrained_embeds = gensim_embeds.vectors

    # To convert words in the input tweet to indices of the embeddings matrix:
    word_to_idx = {word: i for i, word in enumerate(gensim_embeds.index_to_key)}



    # --- set up ---
    # WRITE CODE HERE
    model = FFNN(pretrained_embeds, n_classes)
    loss_function = None
    optimizer = None

    # --- training ---
    for epoch in range(n_epochs):
        total_loss = 0
        for tweet in data['training']:
            gold_class = label_to_idx(tweet['SENTIMENT'])

            # WRITE CODE HERE
            None

        if ((epoch + 1) % report_every) == 0:
            print(f"epoch: {epoch}, loss: {round(total_loss * 100 / len(data['training']), 4)}")

    # Feel free to use the development data to tune hyperparameters if you like!



    # --- test ---
    correct = 0
    with torch.no_grad():
        for tweet in data['dev.gold']:
            gold_class = label_to_idx(tweet['SENTIMENT'])

            # WRITE CODE HERE



            predicted = label_to_idx('neutral')
            correct += torch.eq(predicted, gold_class).item()

            if verbose:
                print('DEV DATA: %s, OUTPUT: %s, GOLD LABEL: %d' %
                      (tweet['BODY'], tweet['SENTIMENT'], predicted))

        print(f"dev accuracy: {round(100 * correct / len(data['dev.gold']), 2)}")

