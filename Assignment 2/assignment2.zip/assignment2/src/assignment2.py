#! /usr/bin/env python3
# -*- encoding: utf-8 -*-

"""
In this assignment you will experiment with sentiment classification.

You will be working with datasets from the 2014 SemEval shared task ``Sentiment analysis in Twitter''.
If you are interested in background information or want to compare your own system to systems which participated
in the competition, please have a look at:

S. Rosenthal, A. Ritter, P. Nakov and V. Stoyanov. SemEval-2014 Task 9: Sentiment Analysis in Twitter. SemEval 2014.
"""


# declare your imports
# you may start with these ones
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.linear_model.logistic import LogisticRegression
from sklearn import preprocessing
import sklearn.metrics

# add the path to the manipulation files if necessary

# this is an example:
# import sys
# sys.path.append('</PATH/TO/DATA/MANIP/FILES>')


# read the data and load it to memory
def load_data():

    # WRITE CODE HERE


# use any vectorizer avaible in scikit-learn to process your features, e.g., TfidfVectorizer, CountVectorizer
def construct_feature_vectors():

    # WRITE CODE HERE


def construct_label_vector():


    # WRITE CODE HERE


def build_and_train_model():

    # WRITE CODE HERE


def evaluate_model():

    # WRITE CODE HERE


# --- "main" ---
def main():


    # WRITE CODE HERE



if __name__ == "__main__":
    main()


